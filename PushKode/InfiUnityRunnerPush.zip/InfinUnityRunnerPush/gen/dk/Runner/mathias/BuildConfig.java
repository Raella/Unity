/** Automatically generated file. DO NOT MODIFY */
package dk.Runner.mathias;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}